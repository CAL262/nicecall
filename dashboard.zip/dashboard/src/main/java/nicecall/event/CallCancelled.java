package nicecall.event;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CallCancelled extends CallEvent {
//    private Long callId; // inherited

}
